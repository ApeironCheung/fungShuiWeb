//DataAPI.js

export * from './Data/localizationData.js';
export * from './Data/subscribeList.js';