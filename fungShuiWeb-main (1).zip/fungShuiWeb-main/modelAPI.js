//modelAPI.js
export * from './Model/API4Numerology.js';
export * from './Model/oracleModel.js';