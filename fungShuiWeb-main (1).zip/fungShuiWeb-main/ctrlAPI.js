//ctrlAPI.js

export * from './Control/login.js';
export * from './Control/controlYear.js';
export * from './Control/switchLang.js';
export * from './Control/switchPage.js';