# fungShuiWeb
calculate fung shui and related things
